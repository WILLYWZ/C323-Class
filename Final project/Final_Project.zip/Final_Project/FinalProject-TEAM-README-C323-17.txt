C323 Spring 2020; Final Project; Team 17 (Scarlet); README file

Kaiju Lyu; kaijlv@iu.edu
Mike Xiong; mikxiong@iu.edu
Yiwei Zhu; yiwzhu@iu.edu

1. Instruction of using this App:
Based on the tab view, we have four main interfaces that construct this app:

A. The view from "Add" tab is the first view you will see when open this app.
It contains the series of interface that represented as the main functionality
of our app.

--> InterfaceA: When you click "Add" on tab, you will see the interface A, contains
a apple time drop bar for you to select the time you want to add to this moment, or
it will show the time on your device as initial time. There are 9 emotion icon under
the time drop bar. You can selec and click the one that represent your feeling at
this moment and then both time and emotion you selected will be recorded. You will
be sent to the enxt interface, interfaceB for selecting more details of the moment.

--> InterfaceB: InterfaceB is part of the Adding functionality UI series, it will
show you 4 Categories of the moment that best match the activity you just been through
corresponds to the emotion and time you just selected. After you select any of those
4 category buttons, you will be redirected to next interfaceC for detailed classification.

--> InterfaceC: It's also a part of adding. Although there are only 5 moments that
corresponds to the categories you selected in interfaceB, it actually can switch
those 5 buttons in the same scene if you select difference category in interfaceB.
After you choose any of those 5 moments that ebst describe what you just been through,
you will get sent to the last UI, interfaceD in the Adding series.

--> InterfaceD: It contains 4 labels of teh date, the emotion, thecategory , and the
moment, which all show the element you just chosed for you to confirm. There are two buttons
under those 4 labels, you can either choose to back to start if there is data not correct
or save the moment you just record. Once get saved, you will be sent to the tab view.

B. UI from "history" in tab is another tableview that you can check the Output emotion moment
you just record in the "Adding". The records in history will show the time, emotion,
category, and moment you choose, decending by the date. There is also a clear button
at upper rigth corner to clear all the history data in the core data storage.

C. UI from "Abreaction" in tab is the feature functionality we want to add for user to
express their emotion when it's hard to control. It contain two buttons, Lincoln painting
and Lincoln Audio that will sent user to the audio recording pge or sketching page to
do speak out their words in mind or crazyly sketch, these method is one time because they
are built for emotion abreaction, we don't want these thing still stored to impact user's
emotion.

D. UI from "Report" in tab is another important functionality that represent another Output
which will show the statistic data of each emotion in a tableview. User can check how many
times they got what emotion and the percentage of each emotion in their whole feeling.

---------------------------------------------------------------------------------------------------

2. The Xcode environment we used for this app is Version 11.3.1(11C505)

---------------------------------------------------------------------------------------------------

3. List of all requirement and extra credits feature

Input: Button
Output: Table elements
Separate View numbers: 14
Number of view controllers: 8
Number of container view controller: 1
Number of table view controller: 2
Extra Point1: Core data storage
The iOS Frameworks used: AVFoundation
Extra iOs Frameworks used: pencilKit  

----------------------------------------------------------------------------------------------------