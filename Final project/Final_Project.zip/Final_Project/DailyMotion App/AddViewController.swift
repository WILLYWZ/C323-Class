//
//  TableViewController.swift
//  DailyMotion App
//
//  Created by Yiwei Zhu on 5/2/20.
//  Copyright © 2020 C323 / Spring 2020. All rights reserved.
//

import UIKit
//controller for the staring page
class AddViewController: UIViewController {

    @IBOutlet weak var datePicker: UIDatePicker!
    var date:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.chooseDate(self.datePicker)
    }
    
    
    @IBAction func feelingClick(_ sender: UIButton) {
        //get user input
        let tag:Int = sender.tag
        // initiate choice options and put it into array of strings.
        let emotionArr:[String] = ["Awkward","Happy","Angry","Cool","Disgusted","Upset","Dead","Nice","Scared"]
        let emotion = emotionArr[tag - 1]
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc:CategoryViewController = storyBoard.instantiateViewController(withIdentifier: "CategoryViewController") as! CategoryViewController
        
        //get date
        vc.date = self.date
        //get emotion
        vc.emotion = emotion
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    //change the date if user gives different inputs using the date picker
    @IBAction func dateChange(_ sender: UIDatePicker) {
        self.chooseDate(self.datePicker)
    }
    
    func chooseDate(_ sender: UIDatePicker) {
        //get date from user input
        let date:Date = sender.date
        let formatter = DateFormatter()
        // make the date into 24 hours format
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //output it as string
        self.date = formatter.string(from: date)
    }
}
