//
//  TableViewController.swift
//  DailyMotion App
//
//  Created by Yiwei Zhu on 5/2/20.
//  Copyright © 2020 C323 / Spring 2020. All rights reserved.
//

import Foundation
import CoreData

// declear CoreData properties
extension Motion {
    
    // this code is auto get from coredata
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Motion> {
        return NSFetchRequest<Motion>(entityName: "Motion")
    }
    
    //define type for the four variables 
    @NSManaged public var time: String?
    @NSManaged public var category: String?
    @NSManaged public var moment: String?
    @NSManaged public var emotion: String?

}
