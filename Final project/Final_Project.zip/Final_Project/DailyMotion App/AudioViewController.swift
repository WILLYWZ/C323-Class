//
//  AudioViewController.swift
//  DailyMotion App
//
//  Created by Lyu, Kaiju on 5/1/20.
//  Copyright © 2020 C323 / Spring 2020. All rights reserved.
//
import UIKit
import Foundation
import AVFoundation

class AudioViewController: UIViewController , AVAudioPlayerDelegate , AVAudioRecorderDelegate {

    //declare the the button objects
    @IBOutlet weak var record: UIButton!
    @IBOutlet weak var play: UIButton!

    //initial instance object as record or play use
    var soundRecorder : AVAudioRecorder!, soundPlayer : AVAudioPlayer!

    override func viewDidLoad() {
        // Do following steps to prepare the record after view is loaded
        super.viewDidLoad()
        let audioFilename = getDirectory().appendingPathComponent(fileName)
        let recordSetting = [ AVFormatIDKey : kAudioFormatAppleLossless,
                              AVEncoderAudioQualityKey : AVAudioQuality.max.rawValue,
                              AVEncoderBitRateKey : 320000,
                              AVNumberOfChannelsKey : 2,
                              AVSampleRateKey : 44100.2] as [String : Any]
        do {
            soundRecorder = try AVAudioRecorder(url: audioFilename, settings: recordSetting )
            soundRecorder.delegate = self
            soundRecorder.prepareToRecord()
        } catch {
            print(error)
        }

        play.isEnabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func getDirectory() -> URL {
        //retrieve the file with a URL path
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }

    var fileName: String = "audioFile.m4a"
    
    func setupPlayer() {
        //set up the player's property
        let audioFilename = getDirectory().appendingPathComponent(fileName)
        do {
            soundPlayer = try AVAudioPlayer(contentsOf: audioFilename)
            soundPlayer.delegate = self
            soundPlayer.prepareToPlay()
            soundPlayer.volume = 1.0
        } catch {
            print(error)
        }
    }

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        //check if the record is finished
        play.isEnabled = true
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        //set the button back when the play finished
        record.isEnabled = true
        play.setTitle("Play", for: .normal)
    }

    @IBAction func recordAudio(_ sender: Any) {
        //Outlet method for the "record" button in the storyboard to record the audio
        if record.titleLabel?.text == "Record" {
            soundRecorder.record()
            record.setTitle("Stop", for: .normal)
            play.isEnabled = false
        } else {
            soundRecorder.stop()
            record.setTitle("Record", for: .normal)
            play.isEnabled = false
        }
    }

    @IBAction func playAudio(_ sender: Any) {
        //Outlet method for the "play" button in the storyboard to play the audio just recorded
        if play.titleLabel?.text == "Play" {
            play.setTitle("Stop", for: .normal)
            record.isEnabled = false
            setupPlayer()
            soundPlayer.play()
        } else {
            soundPlayer.stop()
            play.setTitle("Play", for: .normal)
            record.isEnabled = false
        }
    }
}
