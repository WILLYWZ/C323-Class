//
//  PaintViewController.swift
//  DailyMotion App
//
//  Created by Yiwei Zhu on 5/2/20.
//  Copyright © 2020 C323 / Spring 2020. All rights reserved.
//
import UIKit
import PencilKit

class PaintViewController: UIViewController {
    override func viewDidLoad(){
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        setUpDrawing() // put the setUpDrawing function inside
    }
    
    func setUpDrawing(){
        let backGround = PKCanvasView (frame: self.view.bounds) // set background
        guard let window = view.window,
        let toolBar = PKToolPicker.shared(for: window) else{ return } // set a function, toolbar and window
        toolBar.setVisible(true, forFirstResponder: backGround) // setting for toolbar visible
        toolBar.addObserver(backGround) // set toolbar addboserver
        backGround.becomeFirstResponder()
        view.addSubview(backGround)
    }
}
