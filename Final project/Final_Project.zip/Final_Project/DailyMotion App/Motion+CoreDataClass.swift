//
//  TableViewController.swift
//  DailyMotion App
//
//  Created by Yiwei Zhu on 5/2/20.
//  Copyright © 2020 C323 / Spring 2020. All rights reserved.
//

import Foundation
import CoreData


// declear CoreData class 
@objc(Motion)
public class Motion: NSManagedObject {

}
